
sleep 10
am start -a android.intent.action.MAIN -e toasttext "𝘼𝘿𝘽𝙇𝙊𝘾𝙆 𝙀𝙉𝘼𝘽𝙇𝙀𝘿" -n bellavita.toast/.MainActivity