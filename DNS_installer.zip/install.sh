ui_print "this will redirects to the download page"
ui_print "please select a browser to download magisk module"

am start -a android.intent.action.VIEW -d https://www.pling.com/p/2052590/ >/dev/null 2>&1 & >/dev/null 2>&1
sleep 5

ui_print "if you download the module "
ui_print "please go back and flash the downloaded module"